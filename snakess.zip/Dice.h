#ifndef CDADO_H_INCLUDED
#define CDADO_H_INCLUDED

#include <ctime>
#include <cstdlib>

class Dice{

    public:

        Dice();
        int roll();

};


#endif // CDADO_H_INCLUDED
